import websocket
import json
import keyboard
import time

def send_command(direction):
    """Send control command to the robot."""
    server_ip = "2001:288:6004:17:fff1:cd25:0:a031"  # Replace with your server IPv6
    server_port = 8081
    ws_url = f"ws://[{server_ip}]:{server_port}"

    try:
        ws = websocket.create_connection(ws_url)
        message = json.dumps({"direction": direction})
        ws.send(message)
        print(f"Sent command: {direction}")
        ws.close()
    except Exception as e:
        print(f"Failed to send command {direction}: {e}")

def main():
    print("Press q to send 'q', r to send 'r'.")
    q_pressed = False
    r_pressed = False

    while True:
        try:
            if keyboard.is_pressed("q"):
                if not q_pressed:
                    send_command("q")
                    q_pressed = True
            else:
                q_pressed = False

            if keyboard.is_pressed("r"):
                if not r_pressed:
                    send_command("r")
                    r_pressed = True
            else:
                r_pressed = False

            time.sleep(0.05)
        except Exception as e:
            print(f"Error: {e}")
            break

if __name__ == "__main__":
    main()